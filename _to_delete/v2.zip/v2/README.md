# 전화영어 클래스룸 · 시안4(와옹이) — 개발 전달본 v2

화면을 영역별 HTML 조각(`inc/`)으로 나누고, CSS·JS도 같은 영역 단위로 나눈 버전입니다.
기본 앱은 조각을 모두 조립해서 쓰고, B2B·B2C 웹은 헤더·푸터를 빼고 필요한 조각만 인클루드하면 됩니다.

## 바로 보기

- `screens.html` : 69개 화면 목록. 각 화면마다 기획안 ID·페이지, Figma 프레임 링크, 구현 파일을 함께 보여 줍니다.
- `app.html` : 전체 조립본. 서버 없이 더블클릭으로도 열립니다. `app.html?screen=번호`로 열면 특정 화면 상태를 재현합니다.

## 폴더 구성

| 경로 | 내용 |
|---|---|
| `inc/shell-head.html` | 앱 상단(로고 · 타이틀 · 과정 안내 · 설정) + 클래스룸 탭(수강중/예정/종료) — 앱 전용 |
| `inc/classroom.html` | 클래스룸 내용 (`#scrollArea` 수강중, `#upcomingArea` 예정, `#doneArea` 종료) |
| `inc/schedule.html` | 스케줄 내용 (`#scheduleArea`) |
| `inc/shell-nav.html` | 하단 내비(클래스룸/스케줄) — 앱 전용 |
| `inc/popups.html` | 공통 팝업 전체 (기본 `hidden`, JS로 열림) |
| `inc/native.html` | 네이티브 화면(수업 콜 · 푸시 · 스플래시 · 공지 · 권한) — 앱 전용, 실서비스는 네이티브 구현, 화면 기준용 |
| `css/tokens.css` | 디자인 토큰(`:root` 변수) + 웹폰트. **B2B/B2C 브랜드 테마는 이 파일만 교체** |
| `css/base.css` | 리셋 · 문서 기본값 |
| `css/components.css` | 공통 컴포넌트 (버튼 · 칩 · 탭 · 세그먼트 · 와옹이 캐릭터 · 눌림/등장 인터랙션) |
| `css/shell.css` | 앱 셸 (stage · 헤더 · 탭 · 하단 내비 · 네이티브 화면) — 앱 전용 |
| `css/classroom.css` · `css/schedule.css` · `css/popup.css` | 영역별 화면 |
| `js/core.js` | `YBMP` 공통 (블록 등록·실행, 데모 데이터, 와옹이 이미지 맵 `window.S3C`, 캐릭터 시스템, 인터랙션) |
| `js/classroom.js` · `js/schedule.js` · `js/popup.js` | 영역별 동작 |
| `js/shell.js` | 앱 전용 (수업 콜 · 푸시 · 스플래시 · 공지 · 권한) |
| `js/demo/screen-states.js` | **화면 목록 전용**. `?screen=번호` 상태 재현. 실서비스에 넣지 않음 |
| `data/demo.json` | 데모 데이터 (레슨 · 스케줄 · 질문 내역 · 강사 · 교재 등 24종) — API 응답으로 교체 대상 |
| `app.src.html` · `build.py` | 미리보기 조립 원본과 빌드 스크립트 |
| `images/` | 와옹이 `wawong-N.png`, 로고, 강사 아바타, 푸시 아이콘 |

## 조립 방법

```html
<!-- CSS : 이 순서 유지 (필요 없는 영역 파일은 빼도 됨) -->
<link rel="stylesheet" href="css/tokens.css">
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/components.css">
<link rel="stylesheet" href="css/shell.css">      <!-- 앱 전용 -->
<link rel="stylesheet" href="css/classroom.css">
<link rel="stylesheet" href="css/schedule.css">
<link rel="stylesheet" href="css/popup.css">

<div class="stage">
  <!--#include virtual="/inc/shell-head.html"-->   앱 전용
  <!--#include virtual="/inc/classroom.html"-->
  <!--#include virtual="/inc/schedule.html"-->
  <!--#include virtual="/inc/shell-nav.html"-->    앱 전용
  <!--#include virtual="/inc/popups.html"-->
</div>
<!--#include virtual="/inc/native.html"-->         앱 전용

<script>window.YBMP_DEMO = { ... };</script>       <!-- 실서비스: 서버 데이터로 교체 -->
<script src="js/core.js"></script>
<script src="js/classroom.js"></script>
<script src="js/schedule.js"></script>
<script src="js/popup.js"></script>
<script src="js/shell.js"></script>                 <!-- 앱 전용 -->
<script>YBMP.boot();</script>
```

- **JS 실행 순서** : 각 파일은 `YBMP.add(순번, 이름, 함수)`로 블록을 등록만 하고, 마지막 `YBMP.boot()`가 순번대로 실행합니다. 그래서 파일을 읽는 순서와 상관없이 v1과 같은 순서로 동작합니다. 순번은 바꾸지 마세요.
- **일부 영역만 넣을 때** : 페이지에 없는 영역의 블록이 오류를 내도 다른 블록은 계속 실행됩니다(콘솔에 `[YBMP] 블록이름` 오류만 남음). 실서비스에서는 해당 JS 파일을 빼는 게 깔끔합니다.
- **CSS 영역 경계** : 영역별 파일에 서로의 기본 스타일을 덮어쓰는 규칙이 있으면, 단독 사용 시 깨지지 않도록 공통 파일(`components.css`, `base.css`)로 옮겨 두었습니다. CSS 파일 안의 `(from v1 xxx.css)` 표시는 원래 있던 파일입니다.
- **인코딩** : 모든 파일은 UTF-8입니다. 인클루드할 ASP 페이지가 EUC-KR(코드페이지 949)이면 한글이 깨지니 변환하거나 코드페이지를 맞춰 주세요.
- **앱 / 웹 차이** : 화면 높이 고정(`html`·`body`·`.stage` 100dvh, `.scroll-area` 내부 스크롤)은 모두 `shell.css`에 있습니다. 웹(B2B·B2C)에 넣을 때 `shell.css`를 빼면 사이트 헤더 아래에서 문서 흐름대로 표시됩니다. `classroom` + `popups` 조합을 사이트 헤더 아래에 넣어 표시와 팝업 열림까지 확인했습니다.
- **팝업 위치** : 팝업 오버레이는 `position:fixed`입니다. 사이트 헤더나 GNB의 `z-index`와 겹치지 않는지 확인해 주세요.

## 미리보기 갱신

`inc/`, `app.src.html`, `data/demo.json`을 고친 뒤 `python3 build.py`를 실행하면 `app.html`이 다시 만들어집니다. `app.html`을 직접 고치지 마세요.

## 검증

- v1(`classroom.html`)과 v2(`app.html`)를 69개 화면 × 390 · 768 · 1280px에서 계산된 스타일·위치·텍스트로 비교했고, 차이가 없습니다. 애니메이션 진행 시점에 따른 1px 안팎의 렌더링 차이는 제외했습니다.
- 위 비교를 마친 뒤 아래 디자인 수정 4건을 반영했습니다.

## 디자인 수정 (10/20)

1. **스케줄** : 월간 상단 여백을 주간과 같은 18px로 맞췄습니다. 월간에서 주간으로 돌아오면 맨 위로 이동합니다. 선택한 날에 수업이 있으면 그 날짜와 첫 카드가 보일 만큼만 내려갑니다.
2. **출석현황** : 날짜를 누르면 나오는 정보를 상태 칩 + 두 줄(날짜 / 레슨명)로 바꿨습니다. 레슨명은 한 줄을 넘으면 …으로 줄입니다.
3. **클래스룸 강좌명 줄** : 순서를 과정명 → ⓘ → 화상/전화 칩으로 바꿨습니다.
4. **여러 강좌 표시** : 점 표시를 `1 / 3`으로 바꾸고, 선생님 이름 줄 오른쪽 끝에 두었습니다.

## 이미지

- 와옹이 : `images/wawong-N.png`. 교체는 `js/core.js`의 `window.S3C` 한 곳만 수정하면 됩니다.
- 강좌 이미지 : 서버 경로(`upsisa.ybmsisa.com/.../product/info/*.jpg`)에서 직접 로드합니다.
- 폰트 : Pretendard Variable CDN(jsdelivr v1.3.9) + Plus Jakarta Sans(숫자·영문 강조).

## Figma

파일 `20GzBZGgraOkwqRb5iLsDM` · 페이지 「시안4 · 화면(와옹)」 69개 프레임 (번호 = `screens.html` 번호).

- 화면은 「전화영어 (Phone)」 페이지의 `시안4 · Purple DS` 컴포넌트와 `Phone/` 텍스트 스타일로 구성했습니다.
- 폰트 교체 : 로컬 변수 `family/sans` 값만 `Pretendard`로 바꾸면 됩니다.
